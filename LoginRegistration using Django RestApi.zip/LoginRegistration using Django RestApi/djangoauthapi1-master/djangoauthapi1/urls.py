from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path('admin/', admin.site.urls),
    path('api/user/', include('account.urls')),
    path('api/yoga/', include('yoga.urls')),
    path('api/profile/', include('userProfile.urls')),
    path('api/address/', include('userProfile.urls'))
]

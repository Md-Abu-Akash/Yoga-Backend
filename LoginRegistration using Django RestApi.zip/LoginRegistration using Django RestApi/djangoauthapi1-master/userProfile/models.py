from django.db import models

# Create your models here.
class profile(models.Model):
    name = models.CharField(max_length=100)
    age = models.IntegerField()
    email = models.EmailField()
    height = models.IntegerField()
    weight = models.IntegerField()
    age = models.IntegerField()
    gender = models.CharField(max_length=10)
    address=models.ForeignKey('address',on_delete=models.CASCADE,related_name='address')
    class Meta:
        app_label = 'userProfile'


class address(models.Model):
    id=models.IntegerField(primary_key=True)
    landmark= models.CharField(max_length=500)
    building_nam = models.CharField(max_length=100)
    street = models.CharField(max_length=100)
    area= models.CharField(max_length=500)
    pin=models.CharField(max_length=10)
    city= models.CharField(max_length=100)
    state=models.CharField(max_length=100)
    country=models.CharField(max_length=100)
    class Meta:
        app_label = 'userProfile'




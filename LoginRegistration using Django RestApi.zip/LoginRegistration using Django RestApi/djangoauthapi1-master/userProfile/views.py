from django.shortcuts import render
from userProfile.models import address,profile
from userProfile.serializers import address_serializers,profile_serializers
from rest_framework import viewsets

# Create your views here.
class profileApi(viewsets.ModelViewSet):
    queryset = profile.objects.all()
    serializer_class = profile_serializers

class addressApi(viewsets.ModelViewSet):
    queryset = address.objects.all()
    serializer_class = address_serializers
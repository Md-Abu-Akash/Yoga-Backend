from django.urls import path,include
from yoga.views import yogaApi,catagoryApi
from . import views
from rest_framework.routers import DefaultRouter

router=DefaultRouter()
router.register("address",views.addressApi)
router.register("profile",views.profileApi)
urlpatterns = [
    path('',include(router.urls)),



]
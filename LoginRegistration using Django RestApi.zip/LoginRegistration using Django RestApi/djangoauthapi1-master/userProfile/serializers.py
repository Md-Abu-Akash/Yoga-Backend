from rest_framework import serializers
from userProfile.models import address,profile

class address_serializers(serializers.ModelSerializer):
    class Meta:
        model=address
        fields="__all__"


class profile_serializers(serializers.ModelSerializer):
    profile=address_serializers(read_only=True,many=True)
    class Meta:
        model=profile
        fields="__all__"
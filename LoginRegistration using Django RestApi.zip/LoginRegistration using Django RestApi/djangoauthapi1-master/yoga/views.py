from django.shortcuts import render
from rest_framework.response import Response

from yoga.models import yogaModel,catagoryModel
from yoga.serializers import yoga_serializers,catagory_serializers
from rest_framework import viewsets,generics

# Create your views here.
class yogaApi(generics.ListAPIView):
    serializer_class = yoga_serializers
    def get_queryset(self):
        category = self.kwargs['category']
        if category=='all':
            queryset = yogaModel.objects.all()
            return queryset
        if category is not None and category!='all' :
            queryset= yogaModel.objects.filter(categories=category)
            return queryset


class catagoryApi(viewsets.ModelViewSet):
    serializer_class = catagory_serializers
    def get_queryset(self):
        queryset = catagoryModel.objects.all()
        return queryset

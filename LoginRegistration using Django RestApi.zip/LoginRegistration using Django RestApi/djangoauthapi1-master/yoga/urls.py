from django.urls import path,include
from yoga.views import yogaApi,catagoryApi
from . import views
from rest_framework.routers import DefaultRouter

router=DefaultRouter()
router.register("category",views.catagoryApi,basename='catagory')
urlpatterns = [
    path('',include(router.urls)),
    path('category=<category>/',yogaApi.as_view()),


]
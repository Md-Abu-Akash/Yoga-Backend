from rest_framework import serializers
from yoga.models import yogaModel,catagoryModel

class catagory_serializers(serializers.ModelSerializer):
    class Meta:
        model=catagoryModel
        fields="__all__"


class yoga_serializers(serializers.ModelSerializer):
    catagory=catagory_serializers(read_only=True,many=True)
    class Meta:
        model=yogaModel
        fields="__all__"


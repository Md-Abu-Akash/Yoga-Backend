

from django.db import models

# Create your models here.

class catagoryModel(models.Model):
    catagory_name=models.CharField(max_length=100,primary_key=True ,unique=True)
    catagory_img= models.URLField()
    class Meta:
        app_label = 'yoga'

class yogaModel(models.Model):
    categories=models.ManyToManyField(catagoryModel)
    yoga_id=models.IntegerField(primary_key=True)
    yoga_name=models.CharField(max_length=100)
    yoga_img1=models.URLField()
    yoga_img2 = models.URLField()
    yoga_video=models.URLField()
    yoga_des=models.CharField(max_length=500)
    # yoga_catagory=models.ForeignKey('catagoryModel',on_delete=models.CASCADE,related_name='catagory')

    class Meta:
        app_label = 'yoga'




